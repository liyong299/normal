/**
 * 项目名称：missorders
 * 文件包名：cn.mopon.cec
 * 文件名称：queryShowsSchedul.java
 * 版本信息：SCEC_Branches
 * 生成日期：2016年4月29日 下午12:13:53
 * Copyright (c) 2015-2015深圳市泰久信息系统股份有限公司
 * 
 */
package cn.mopon.cec;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 功能描述：<p color="red">从泰久云到SCEC中权益库部分同步，包括：权益卡表、权益卡续费表、权益卡用户表</p>
 * 文件名称：queryShowsSchedul.java
 * @author ly
 */
public class BCSyncSAAS2SCEC {

	private Connection srcConn;

	private Connection destConn;

	String srcUrl = "jdbc:mysql://172.16.34.48:3306/cec?autoReconnect=true&amp;characterEncoding=UTF-8&allowMultiQueries=true";
	String srcUsername = "cec";
	String srcPassword = "cec";

	String destUrl = "jdbc:mysql://172.16.34.13:3306/cec?autoReconnect=true&amp;characterEncoding=UTF-8&allowMultiQueries=true";
	String destUsername = "cec";
	String destPassword = "cec";

	private BCSyncSAAS2SCEC(String srcUrl, String srcUsername, String srcPassword, String destUrl,
			String destUsername, String destPassword) {
		this.srcUrl = srcUrl;
		this.srcUsername = srcUsername;
		this.srcPassword = srcPassword;
		this.destUrl = destUrl;
		this.destUsername = destUsername;
		this.destPassword = destPassword;
	}
    /**
     * <p>功能描述：<p>方法功能</p></p>
     * <p>实现逻辑：<p>实现步骤</p></p>
     * @param args
     */
    public static void main(String[] args) {
		if (args == null || args.length < 6) {
			System.out.println("需要配置参数错误");
			return;
		}
		BCSyncSAAS2SCEC service = new BCSyncSAAS2SCEC(args[0], args[1], args[2], args[3], args[4], args[5]);
		service.bcSyncSAAS2SCEC();
    }
    
	private void bcSyncSAAS2SCEC() {
		// 1、打开连接
		srcConn = getConn(srcUrl, srcUsername, srcPassword);
		destConn = getConn(destUrl, destUsername, destPassword);
		// 2、同步新增或修改权益卡用户表，无法删除  [SAAS-SCEC 库不会更新这个表，只会有SCEC更新后同步过来]
		//		syncBCUser();  
		// 3、同步新增或修改权益卡表，无法删除
		syncBC();
		
		// 4、同步新增或修改权益卡续费表，无法删除 [SAAS-SCEC 库不会更新这个表，只会有SCEC更新后同步过来]

		// 5、关闭连接
		close(srcConn, null, null);
		close(destConn, null, null);
	}


	private void syncBC() {
		try {
			String selectSql = "SELECT * from CEC_BenefitCardOrder x where x.modifyDate > DATE_ADD(NOW(),INTERVAL -100 MINUTE)";
			String format = "UPDATE CEC_BenefitCard SET $1$ WHERE $2$";

			List<String> excludeFields = Arrays.asList(new String[] { "id", "typeId", "userId", "channelId",
					"levelId", "code", "channelOrderCode", "birthday", "createDate", "modifyDate" });
			String sql = genUpdateSQL(selectSql, format, excludeFields);
			System.out.println(sql);
			executeAllRecords(this.destConn, sql);

		} catch (IOException e) {
			System.out.println("新增权益卡用户失败");
			e.printStackTrace();
		}
	}

	// 查询全是原始库
	private String genUpdateSQL(String selectSql, String format, List<String> excludeFields)
			throws IOException {
		List<Map<String, String>> bcs = queryAllRecords(this.srcConn, selectSql);

		if (bcs == null || bcs.size() == 0) {
			System.out.println("本次查询无数据变化：[ " + selectSql + "]");
			return null;
		}

		StringBuffer updateSQL = new StringBuffer();
		for (Map<String, String> map : bcs) {
			StringBuilder fields = new StringBuilder();
			StringBuilder values = new StringBuilder();
			for (Map.Entry<String, String> entry : map.entrySet()) {
				if (!excludeFields.contains(entry.getKey())) {
					if (entry.getValue() == null) {
						fields.append(entry.getKey()).append("=").append("null,");
					} else {
						fields.append(entry.getKey()).append("='").append(entry.getValue()).append("',");
					}
				}
				if ("id".equals(entry.getKey().toLowerCase())) {
					values.append("id='").append(entry.getValue()).append("'");
				}
			}
			updateSQL
					.append(format.replace("$1$", fields.substring(0, fields.length() - 1)).replace("$2$",
							values)).append(";").append(System.getProperty("line.separator"));
		}
		return updateSQL.toString();
	}

	@SuppressWarnings("unused")
	private String genInsertSQL(String selectSql, String format)
			throws IOException {
		List<Map<String, String>> bcs = queryAllRecords(this.srcConn, selectSql);

		if (bcs == null || bcs.size() == 0) {
			System.out.println("本次查询无数据变化：[ " + selectSql + "]");
			return null;
		}

		StringBuffer insertSQL = new StringBuffer();
		for (Map<String, String> map : bcs) {
			StringBuilder fields = new StringBuilder();
			StringBuilder values = new StringBuilder();
			for (Map.Entry<String, String> entry : map.entrySet()) {
				fields.append(entry.getKey()).append(",");
				if (entry.getValue() == null) {
					values.append(entry.getValue()).append(",");
				} else {
					values.append('\'').append(entry.getValue()).append("\',");
				}
			}
			insertSQL.append(
					format.replace("$1$", fields.substring(0, fields.length() - 1)).replace("$2$",
							values.substring(0, values.length() - 1))).append(";");
		}
		return insertSQL.toString();
	}



	private Connection getConn(String url, String password, String username) {
		String driver = "com.mysql.jdbc.Driver";

		Connection conn = null;
		try {
			Class.forName(driver);
			conn = (Connection) DriverManager.getConnection(url, username, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

	// 查询记录
	private List<Map<String, String>> queryAllRecords(Connection conn, String sqlP) {
		String sql = sqlP;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			ResultSetMetaData meta = rs.getMetaData();
			int col = meta.getColumnCount();

			List<Map<String, String>> result = new ArrayList<>();
			while (rs.next()) {
				Map<String, String> fields = new LinkedHashMap<>();
				for (int i = 1; i <= col; i++) {
					fields.put(meta.getColumnName(i), rs.getString(i));
				}
				result.add(fields);
			}
			return result;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(null, rs, pstmt);
		}
		return null;
	}

	// 查询记录
	private void executeAllRecords(Connection conn, String sqlP) {
		String sql = sqlP;
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(null, null, pstmt);
		}
	}

	private static void close(Connection conn, ResultSet rs, PreparedStatement pstmt) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}