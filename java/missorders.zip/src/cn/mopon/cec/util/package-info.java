/**
 * 项目名称：missorders
 * 文件包名：cn.mopon.cec.util
 * 文件名称：package-info.java
 * 版本信息：SCEC_Branches
 * 生成日期：2016年12月21日 下午3:08:14
 * Copyright (c) 2015-2015深圳市泰久信息系统股份有限公司
 * 
 */
/**
 * @功能描述：
 * @文件名称：package-info.java
 * @author ly
 */
package cn.mopon.cec.util;