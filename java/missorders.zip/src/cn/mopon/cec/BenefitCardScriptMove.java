package cn.mopon.cec;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 权益卡迁移脚本
 */
public class BenefitCardScriptMove {
	static String driver = "com.mysql.jdbc.Driver";
	
	/**scec数据库*/
	static String url = "jdbc:mysql://172.16.10.176:3306/cec_zy?autoReconnect=true&amp;characterEncoding=UTF-8&allowMultiQueries=true";
	static String user = "cec";
	static String password = "yaocheng123";
	
	/**saas数据库*/
	static String saasUrl = "jdbc:mysql://172.16.34.48:3306/ZY_DEVELOP?autoReconnect=true&amp;characterEncoding=UTF-8&allowMultiQueries=true";
	static String saasUser = "cec";
	static String saasPassword = "cec";

	
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// 1、查询权益卡类型。并生成相应SQL
		genBCTypeSQL();
		
		// 1.1、生成对应的等级SQL，返回等级和权益卡对应关系
		gentMemberLevelSQL();
		
		// 2、查询权益卡渠道。并生成相应SQL
		genBCTypeChannelSQL();

		// 7、查询渠道。
		genChannelSQL();

		// 8、查询渠道设置。
		genChannelSettingSQL();

		// 9、查询渠道。
		genBCSQL();

		// 10、查询渠道设置。
		genBCUserSQL();

		// 11、查询渠道设置。
		genBCRechargeOrderSQL();

		// 12、系统参数表。
		genCircuitSettingsSQL();

		// 13、接入类型表。
		genTicketAccessTypeSQL();
		 

	}
	
	private static void genTicketAccessTypeSQL() {
		String selectSql = "SELECT * from CEC_TicketAccessType"; 
		String sqlFormat = "INSERT INTO CEC_TicketAccessType($1$) VALUES($2$)";

		String sql = gentSQL(selectSql, sqlFormat);
		executeAllRecords(sql);
	}
	
	private static void genCircuitSettingsSQL() {
		String selectSql = "SELECT * from CEC_CircuitSettings"; 
		String sqlFormat = "INSERT INTO CEC_CircuitSettings($1$) VALUES($2$)";

		List<Map<String, String>> bcs = getAll(selectSql);
		String format = sqlFormat;

		StringBuffer updateSQL = new StringBuffer();
		
		for (Map<String, String> map : bcs) {
			StringBuilder fields = new StringBuilder();
			StringBuilder values = new StringBuilder();
			for (Map.Entry<String, String> entry : map.entrySet()) {
				fields.append(entry.getKey()).append(",");
				if (entry.getValue() == null) {
					values.append(entry.getValue()).append(",");
				} else {
					values.append('\'').append(entry.getValue()).append("\',");
				}
			}
			fields.append("audit");
			values.append(defalut("1"));

			String sql = format.replace("$1$", fields).replace("$2$",
					values.substring(0, values.length() - 1))
					+ ";" + System.getProperty("line.separator");
			updateSQL.append(sql);
			
		}
		executeAllRecords(updateSQL.toString());
	}

	private static void genBCRechargeOrderSQL() {
		String selectSql = "SELECT * from CEC_BenefitCardRechargeOrder";
		String sqlFormat = "INSERT INTO CEC_BenefitCardRechargeOrder($1$) VALUES($2$)";

		String sql = gentSQL(selectSql, sqlFormat);
		executeAllRecords(sql);
	}

	private static void genBCUserSQL() {
		String selectSql = "SELECT * from CEC_BenefitCardUser";
		String sqlFormat = "INSERT INTO CEC_BenefitCardUser($1$) VALUES($2$)";

		String sql = gentSQL(selectSql, sqlFormat);
		executeAllRecords(sql);
	}

	private static void genBCSQL() {
		String selectSql = "SELECT * from CEC_BenefitCard";
		String sqlFormat = "INSERT INTO CEC_BenefitCard($1$) VALUES($2$)";

		String sql = gentSQL(selectSql, sqlFormat);
		executeAllRecords(sql);
	}

	private static void genChannelSettingSQL() {
		String selectSql = "SELECT * from CEC_ChannelSettings";
		String sqlFormat = "INSERT INTO CEC_ChannelSettings($1$) VALUES($2$)";

		String sql = gentSQL(selectSql, sqlFormat);
		executeAllRecords(sql);
	}

	private static void genChannelSQL() {
		String selectSql = "SELECT * from CEC_Channel";
		String sqlFormat = "INSERT INTO CEC_Channel($1$) VALUES($2$)";

		List<Map<String, String>> bcs = getAll(selectSql);
		String format = sqlFormat;

		StringBuffer updateSQL = new StringBuffer();
		
		for (Map<String, String> map : bcs) {
			StringBuilder fields = new StringBuilder();
			StringBuilder values = new StringBuilder();
			for (Map.Entry<String, String> entry : map.entrySet()) {
				fields.append(entry.getKey()).append(",");
				if (entry.getValue() == null) {
					values.append(entry.getValue()).append(",");
				} else {
					values.append('\'').append(entry.getValue()).append("\',");
				}
			}
			fields.append("myChannel");
			values.append(defalut("1"));

			String sql = format.replace("$1$", fields).replace("$2$",
					values.substring(0, values.length() - 1))
					+ ";" + System.getProperty("line.separator");
			updateSQL.append(sql);
		}
		executeAllRecords(updateSQL.toString());
	}

	

	private static void genBCTypeSQL() {
		String selectSql = "SELECT * from CEC_BenefitCardType";
		String sqlFormat = "INSERT INTO CEC_BenefitCardType($1$) VALUES($2$)";

		String sql = gentSQL(selectSql, sqlFormat);
		executeAllRecords(sql);
	}

	private static void genBCTypeChannelSQL() {
		String selectSql = "SELECT * from CEC_BenefitCardType_Channel";
		String sqlFormat = "INSERT INTO CEC_BenefitCardType_Channel($1$) VALUES($2$)";

		String sql = gentSQL(selectSql, sqlFormat);
		executeAllRecords(sql);
	}
	

	private static void gentMemberLevelSQL() {
		List<Map<String, String>> bcs = getAll("SELECT * from CEC_BenefitCardType");
		
		String format = "INSERT INTO CEC_BenefitCardMemberLevel($1$) VALUES($2$)";
		
		StringBuffer updateSQL = new StringBuffer();
		
		for (Map<String, String> map : bcs) {
			String fields = "id,name,rate,initAmount,rechargeAmount,totalDiscountCount,dailyDiscountCount,typeId,levelCode,levelType,creatorId,createDate,modifierId,modifyDate";
			StringBuilder values = new StringBuilder();

			String levelId = UUID.randomUUID().toString();
			values.append(defalut(levelId)).append(defalut(map.get("name") + "等级"))
					.append(defalut("rate"));
			values.append(defalut(map.get("initAmount"))).append(defalut(map.get("rechargeAmount")))
					.append(defalut(map.get("totalDiscountCount")))
					.append(defalut(map.get("dailyDiscountCount"))).append(defalut(map.get("id")))
					.append(defalut("20150101" + map.get("code"))).append(defalut("0"))
					.append(defalut(map.get("creatorId")))
					.append(defalut(map.get("createDate"))).append(defalut(map.get("modifierId")))
					.append(defalut(map.get("modifyDate")));

			String sql = format.replace("$1$", fields).replace("$2$",
					values.substring(0, values.length() - 1))
					+ ";"
					+ System.getProperty("line.separator");
			updateSQL.append(sql);
		}
		executeAllRecords(updateSQL.toString());
	}

	private static String defalut(String str) {
		if (str == null) {
			return str + ",";
		} else {
			return '\'' + str + "\',";
		}
	}

	private static String gentSQL(String selectSql, String sqlFormat) {
		List<Map<String, String>> bcs = getAll(selectSql);
		String format = sqlFormat;

		StringBuffer updateSQL = new StringBuffer();
		
		for (Map<String, String> map : bcs) {
			StringBuilder fields = new StringBuilder();
			StringBuilder values = new StringBuilder();
			for (Map.Entry<String, String> entry : map.entrySet()) {
				if ("tap".equals(entry.getKey())) {
					continue;
				}
				fields.append(entry.getKey()).append(",");
				if (entry.getValue() == null) {
					values.append(entry.getValue()).append(",");
				} else {
					values.append('\'').append(entry.getValue()).append("\',");
				}
			}
			String sql = format.replace("$1$", fields.substring(0, fields.length() - 1)).replace("$2$",
					values.substring(0, values.length() - 1))
					+ ";"
					+ System.getProperty("line.separator");
			updateSQL.append(sql);
			
		}
		return updateSQL.toString();
	}

	//scec数据库
	private static Connection getConn() {
		String driver = BenefitCardScriptMove.driver;
		String url = BenefitCardScriptMove.url;
		String username = BenefitCardScriptMove.user;
		String password = BenefitCardScriptMove.password;
		Connection conn = null;
		try {
			Class.forName(driver);
			//classLoader,加载对应驱动
			conn = (Connection) DriverManager.getConnection(url, username, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

	//读数据。
	private static List<Map<String, String>> getAll(String sqlP) {
		Connection conn = getConn();
		String sql = sqlP;
		PreparedStatement pstmt;
		try {
			pstmt = (PreparedStatement) conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			ResultSetMetaData meta = rs.getMetaData();
			int col = meta.getColumnCount();

			System.out.println("");
			List<Map<String, String>> result = new ArrayList<>();
			while (rs.next()) {
				Map<String, String> fields = new LinkedHashMap<>();
				for (int i = 1; i <= col; i++) {
					fields.put(meta.getColumnName(i), rs.getString(i));
				}

				result.add(fields);
			}

			return result;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	//saas数据库
	private static Connection getConnSaas() {
		String driver = BenefitCardScriptMove.driver;
		String url = BenefitCardScriptMove.saasUrl;
		String username = BenefitCardScriptMove.saasUser;
		String password = BenefitCardScriptMove.saasPassword;
		Connection conn = null;
		try {
			Class.forName(driver);
			//classLoader,加载对应驱动
			conn = (Connection) DriverManager.getConnection(url, username, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	//写数据。
	private static void executeAllRecords(String sqlP) {
		Connection conn = getConnSaas();
		String sql = sqlP;
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(null, null, pstmt);
		}
	}
	
	//关闭连接。
	private static void close(Connection conn, ResultSet rs, PreparedStatement pstmt) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
