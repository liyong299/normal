package cn.mopon.cec;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import cn.mopon.cec.util.FileUtils;

/**
 * @功能描述：
 * @文件名称：权益卡迁移脚本.java
 * @author ly
 */
public class BenefitCardScriptMoveRun {

	//	static String url = "jdbc:mysql://172.16.10.176:3306/cec_zy";
	//	static String user = "root";
	//	static String password = "123456";

	static String url = "jdbc:mysql://172.16.34.13:3306/cec?autoReconnect=true&amp;characterEncoding=UTF-8&allowMultiQueries=true";
	static String user = "cec";
	static String password = "cec";

	static String sqlFilePath = "E:/01_work/02_cec/03_需求/03_幸福蓝海/13_SAAS化/04_权益卡同步/new.sql";
	static File sqlFile = null;
	static {
		sqlFile = new File(sqlFilePath);
		try {
			FileUtils.write(sqlFile, "", false);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// 1、查询权益卡类型。并生成相应SQL
		List<Map<String, String>> bcs = genBCTypeSQL();
		// 1.1、生成对应的等级SQL，返回等级和权益卡对应关系
		Map<String, String> bcTypeLevel = gentMemberLevelSQL(bcs);
		// 2、查询权益卡渠道。并生成相应SQL
		genBCTypeChannelSQL();
		// 3、查询权益卡票务规则。并生成相应SQL
		//		genBCTypeRuleSQL(bcTypeLevel);
		// 4、查询权益卡票务规则-影厅关联表。。并生成相应SQL
		//		genBCTypeRuleHallSQL();
		// 5、查询权益卡卖品规则。并生成相应SQL
		//		genBCTypeSnackRuleSQL(bcTypeLevel);
		// 6、查询权益卡卖品规则-卖品。并生成相应SQL
		//		genBCTypeSnackRuleSnackSQL();

		// 7、查询渠道。
		genChannelSQL();

		// 8、查询渠道设置。
		genChannelSettingSQL();

		// 9、查询权益卡。
		genBCSQL();

		// 10、查询渠道设置。
		genBCUserSQL();

		// 11、查询渠道设置。
		genBCRechargeOrderSQL();

		// 12、系统参数表。
		genCircuitSettingsSQL();

		// 13、接入类型表。
		genTicketAccessTypeSQL();

		java.awt.Desktop.getDesktop().open(sqlFile.getParentFile());
	}
	
	private static List<Map<String, String>> genTicketAccessTypeSQL() throws IOException {
		String selectSql = "SELECT * from CEC_TicketAccessType"; 
		String sqlFormat = "INSERT INTO CEC_TicketAccessType($1$) VALUES($2$)";

		return gentSQL(selectSql, sqlFormat);
	}
	
	private static List<Map<String, String>> genCircuitSettingsSQL() throws IOException {
		String selectSql = "SELECT * from CEC_CircuitSettings"; 
		String sqlFormat = "INSERT INTO CEC_CircuitSettings($1$) VALUES($2$)";

		List<Map<String, String>> bcs = getAll(selectSql);
		String format = sqlFormat;

		for (Map<String, String> map : bcs) {
			StringBuilder fields = new StringBuilder();
			StringBuilder values = new StringBuilder();
			for (Map.Entry<String, String> entry : map.entrySet()) {
				fields.append(entry.getKey()).append(",");
				if (entry.getValue() == null) {
					values.append(entry.getValue()).append(",");
				} else {
					values.append('\'').append(entry.getValue()).append("\',");
				}
			}
			fields.append("audit");
			values.append(defalut("1"));

			String sql = format.replace("$1$", fields).replace("$2$",
					values.substring(0, values.length() - 1))
					+ ";" + System.getProperty("line.separator");
			FileUtils.write(sqlFile, sql, true);
			System.out.println(sql);
		}
		return bcs;
	}

	private static List<Map<String, String>> genBCRechargeOrderSQL() throws IOException {
		String selectSql = "SELECT * from CEC_BenefitCardRechargeOrder";
		String sqlFormat = "INSERT INTO CEC_BenefitCardRechargeOrder($1$) VALUES($2$)";

		return gentSQL(selectSql, sqlFormat);
	}

	private static List<Map<String, String>> genBCUserSQL() throws IOException {
		String selectSql = "SELECT * from CEC_BenefitCardUser";
		String sqlFormat = "INSERT INTO CEC_BenefitCardUser($1$) VALUES($2$)";

		return gentSQL(selectSql, sqlFormat);
	}

	private static List<Map<String, String>> genBCSQL() throws IOException {

		String selectSql = "SELECT * from CEC_BenefitCard";
		String sqlFormat = "INSERT INTO CEC_BenefitCard($1$) VALUES($2$)";

		return gentSQL(selectSql, sqlFormat);
	}

	private static List<Map<String, String>> genChannelSettingSQL() throws IOException {
		String selectSql = "SELECT * from CEC_ChannelSettings";
		String sqlFormat = "INSERT INTO CEC_ChannelSettings($1$) VALUES($2$)";

		return gentSQL(selectSql, sqlFormat);
		//		return gentMemberLevelSQL(bcs);
	}

	private static List<Map<String, String>> genChannelSQL() throws IOException {
		String selectSql = "SELECT * from CEC_Channel";
		String sqlFormat = "INSERT INTO CEC_Channel($1$) VALUES($2$)";

		List<Map<String, String>> bcs = getAll(selectSql);
		String format = sqlFormat;

		for (Map<String, String> map : bcs) {
			StringBuilder fields = new StringBuilder();
			StringBuilder values = new StringBuilder();
			for (Map.Entry<String, String> entry : map.entrySet()) {
				fields.append(entry.getKey()).append(",");
				if (entry.getValue() == null) {
					values.append(entry.getValue()).append(",");
				} else {
					values.append('\'').append(entry.getValue()).append("\',");
				}
			}
			fields.append("myChannel");
			values.append(defalut("1"));

			String sql = format.replace("$1$", fields).replace("$2$",
					values.substring(0, values.length() - 1))
					+ ";" + System.getProperty("line.separator");
			FileUtils.write(sqlFile, sql, true);
			System.out.println(sql);
		}
		return bcs;
	}

	private static List<Map<String, String>> genBCTypeSnackRuleSnackSQL() throws IOException {
		String selectSql = "SELECT * from CEC_BenefitCardTypeSnackRule_Snack";
		String sqlFormat = "INSERT INTO CEC_BenefitCardTypeSnackRule_Snack($1$) VALUES($2$)";

		return gentSQL(selectSql, sqlFormat);
		//		return gentMemberLevelSQL(bcs);
	}

	private static List<Map<String, String>> genBCTypeRuleHallSQL() throws IOException {
		String selectSql = "SELECT * from CEC_BenefitCardTypeRule_Hall";
		String sqlFormat = "INSERT INTO CEC_BenefitCardTypeRule_Hall($1$) VALUES($2$)";

		return gentSQL(selectSql, sqlFormat);
		//		return gentMemberLevelSQL(bcs);
	}

	private static List<Map<String, String>> genBCTypeSQL() throws IOException {
		String selectSql = "SELECT * from CEC_BenefitCardType";
		String sqlFormat = "INSERT INTO CEC_BenefitCardType($1$) VALUES($2$)";

		return gentSQL(selectSql, sqlFormat);
		//		return gentMemberLevelSQL(bcs);
	}

	private static void genBCTypeChannelSQL() throws IOException {
		String selectSql = "SELECT * from CEC_BenefitCardType_Channel";
		String sqlFormat = "INSERT INTO CEC_BenefitCardType_Channel($1$) VALUES($2$)";

		List<Map<String, String>> bcs = gentSQL(selectSql, sqlFormat);
	}

	private static List<Map<String, String>> genBCTypeRuleSQL(Map<String, String> bcTypeLevel)
			throws IOException {
		String selectSql = "SELECT * from CEC_BenefitCardTypeRule";
		String sqlFormat = "INSERT INTO CEC_BenefitCardTypeRule($1$) VALUES($2$)";

		List<Map<String, String>> bcs = getAll(selectSql);
		String format = sqlFormat;

		for (Map<String, String> map : bcs) {
			StringBuilder fields = new StringBuilder();
			StringBuilder values = new StringBuilder();
			for (Map.Entry<String, String> entry : map.entrySet()) {
				fields.append(entry.getKey()).append(",");
				if (entry.getValue() == null) {
					values.append(entry.getValue()).append(",");
				} else {
					values.append('\'').append(entry.getValue()).append("\',");
				}
			}
			fields.append("memberLevelId");
			values.append(defalut(bcTypeLevel.get(map.get("typeId"))));

			String sql = format.replace("$1$", fields).replace("$2$",
					values.substring(0, values.length() - 1))
					+ ";"
					+ System.getProperty("line.separator");
			FileUtils.write(sqlFile, sql, true);
			System.out.println(sql);
		}
		return bcs;
	}

	private static List<Map<String, String>> genBCTypeSnackRuleSQL(Map<String, String> bcTypeLevel)
			throws IOException {
		String selectSql = "SELECT * from CEC_BenefitCardTypeSnackRule";
		String sqlFormat = "INSERT INTO CEC_BenefitCardTypeSnackRule($1$) VALUES($2$)";

		List<Map<String, String>> bcs = getAll(selectSql);
		String format = sqlFormat;

		for (Map<String, String> map : bcs) {
			StringBuilder fields = new StringBuilder();
			StringBuilder values = new StringBuilder();
			for (Map.Entry<String, String> entry : map.entrySet()) {
				fields.append(entry.getKey()).append(",");
				if (entry.getValue() == null) {
					values.append(entry.getValue()).append(",");
				} else {
					values.append('\'').append(entry.getValue()).append("\',");
				}
			}
			fields.append("memberLevelId");
			values.append(defalut(bcTypeLevel.get(map.get("typeId"))));

			String sql = format.replace("$1$", fields).replace("$2$",
					values.substring(0, values.length() - 1))
					+ ";"
					+ System.getProperty("line.separator");
			FileUtils.write(sqlFile, sql, true);
			System.out.println(sql);
		}
		return bcs;
	}

	private static Map<String, String> gentMemberLevelSQL(List<Map<String, String>> bcs)
			throws IOException {
		String format = "INSERT INTO CEC_BenefitCardMemberLevel($1$) VALUES($2$)";

		Map<String, String> bcTypeLevel = new HashMap<String, String>();
		for (Map<String, String> map : bcs) {
			String fields = "id,name,rate,initAmount,rechargeAmount,totalDiscountCount,dailyDiscountCount,typeId,levelCode,levelType,creatorId,createDate,modifierId,modifyDate";
			StringBuilder values = new StringBuilder();

			String levelId = UUID.randomUUID().toString();
			values.append(defalut(levelId)).append(defalut(map.get("name") + "等级"))
					.append(defalut("rate"));
			values.append(defalut(map.get("initAmount"))).append(defalut(map.get("rechargeAmount")))
					.append(defalut(map.get("totalDiscountCount")))
					.append(defalut(map.get("dailyDiscountCount"))).append(defalut(map.get("id")))
					.append(defalut("20150101" + map.get("code"))).append(defalut("0"))
					.append(defalut(map.get("creatorId")))
					.append(defalut(map.get("createDate"))).append(defalut(map.get("modifierId")))
					.append(defalut(map.get("modifyDate")));

			String sql = format.replace("$1$", fields).replace("$2$",
					values.substring(0, values.length() - 1))
					+ ";"
					+ System.getProperty("line.separator");
			FileUtils.write(sqlFile, sql, true);
			
			bcTypeLevel.put(map.get("id"), levelId);
			System.out.println(sql);
		}
		return bcTypeLevel;
	}

	private static String defalut(String str) {
		if (str == null) {
			return str + ",";
		} else {
			return '\'' + str + "\',";
		}
	}

	private static List<Map<String, String>> gentSQL(String selectSql, String sqlFormat) throws IOException {
		List<Map<String, String>> bcs = getAll(selectSql);
		String format = sqlFormat;

		for (Map<String, String> map : bcs) {
			StringBuilder fields = new StringBuilder();
			StringBuilder values = new StringBuilder();
			for (Map.Entry<String, String> entry : map.entrySet()) {
				if ("tap".equals(entry.getKey())) {
					continue;
				}
				fields.append(entry.getKey()).append(",");
				if (entry.getValue() == null) {
					values.append(entry.getValue()).append(",");
				} else {
					values.append('\'').append(entry.getValue()).append("\',");
				}
			}
			String sql = format.replace("$1$", fields.substring(0, fields.length() - 1)).replace("$2$",
					values.substring(0, values.length() - 1))
					+ ";"
					+ System.getProperty("line.separator");
			FileUtils.write(sqlFile, sql, true);
			System.out.println(sql);
		}
		return bcs;
	}

	private static Connection getConn() {
		String driver = "com.mysql.jdbc.Driver";
		String url = BenefitCardScriptMoveRun.url;
		String username = BenefitCardScriptMoveRun.user;
		String password = BenefitCardScriptMoveRun.password;
		Connection conn = null;
		try {
			Class.forName(driver);
			//classLoader,加载对应驱动
			conn = (Connection) DriverManager.getConnection(url, username, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

	private static List<Map<String, String>> getAll(String sqlP) {
		Connection conn = getConn();
		String sql = sqlP;
		PreparedStatement pstmt;
		try {
			pstmt = (PreparedStatement) conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			ResultSetMetaData meta = rs.getMetaData();
			int col = meta.getColumnCount();

			//			for (int i = 1; i <= col; i++) {
			//				System.out.print(meta.getColumnName(i) + "\t");
			//				if ((i == 2) && (meta.getColumnName(i).length() < 8)) {
			//					System.out.print("\t");
			//				}
			//			}
			System.out.println("");
			List<Map<String, String>> result = new ArrayList<>();
			while (rs.next()) {
				Map<String, String> fields = new LinkedHashMap<>();
				for (int i = 1; i <= col; i++) {
					fields.put(meta.getColumnName(i), rs.getString(i));
					//					System.out.print(rs.getString(i) + "\t");
					//					if ((i == 2) && (rs.getString(i).length() < 8)) {
					//						System.out.print("\t");
					//					}
				}

				result.add(fields);
				//				genBCMeberLevelSQL(fields);
				//				System.out.println("");
			}

			//			System.out.println("============================");
			return result;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
