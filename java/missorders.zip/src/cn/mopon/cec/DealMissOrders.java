package cn.mopon.cec;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DealMissOrders {
	static PreparedStatement ps;
	static Connection conn;

	public static void main(String[] args) 
	{
		if (args == null || args.length < 6) 
		{
			System.out.println("����ȷ�������������˳��dbURL��dbUserName��dbPasswd��"
					+ "destTableName��srcTableName��priTime");
			return;
		}

		String dbURL = args[0];
		String dbUserName = args[1];
		String dbPasswd = args[2];

		String destTableName = args[3];
		String srcTableName = args[4];
		String priTime = args[5];

		DealMissOrders deal = new DealMissOrders();
		conn = deal.getConn(dbURL, dbUserName, dbPasswd);

		try {
			deal.dealTicketOrder(destTableName, srcTableName, priTime);
//			deal.dealSnakOrder();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("data deal success!");
			deal.closeAll(null, ps, conn);
		}
	}
	
	private void dealDuplicatSend()
	  {
	    String sql = "update CEC_OrderSendRecord set sendState = 1  where msg like 'ModifyByPatch_��������ʧ��,��ʾ:�����ھ���Ψһ���� %';";

	    System.out.println("sql : " + sql);
	    try
	    {
	      ps = conn.prepareStatement(sql);
	      int num = ps.executeUpdate();
	      System.out.println("deal num is : " + num);
	    } catch (Exception e) {
	      e.printStackTrace();
	    } finally {
	      System.out.println("data deal success!");
	      closeAll(null, ps, null);
	    }
	  }
	
	/**
	 * ������Ʒ©��������
	 * 
	 * @param destTableName
	 * @param srcTableName
	 * @param priTime
	 */
	private void dealSnakOrder()
	{
		// �ж϶������ͱ��в����ڣ��򽫶������еļ�¼���뵽���ͱ��С�
		String sql = "INSERT INTO CEC_OrderSendRecord (	SELECT ord.id,NULL,	ord.id,	'0','2','©�ƶ���',now() "
				+ "FROM	CEC_SnackOrder ord	WHERE ord. STATUS IN ('4', '5') AND ticketOrderId is NULL "
				+ "AND ord.id NOT IN ("
				+ "SELECT rec.snackOrderId FROM CEC_OrderSendRecord rec WHERE rec.snackOrderId IS NOT NULL) "
				+ ")";

		System.out.println("sql : " + sql);

		try {
			ps = conn.prepareStatement(sql);
			int num = ps.executeUpdate();
			System.out.println("deal num is : " + num);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("data deal success!");
			closeAll(null, ps, null);
		}
	}

	/**
	 * ����Ʊ��©��������
	 * 
	 * @param destTableName
	 * @param srcTableName
	 * @param priTime
	 */
	private void dealTicketOrder(String destTableName, String srcTableName,
			String priTime) 
	{
		// �ж϶������ͱ��в����ڣ��򽫶������еļ�¼���뵽���ͱ��С�
		String sql = "insert into "
				+ destTableName
				+ "(id, orderid, snackOrderid, sendstate,ordertype,msg,sendtime) "
				+ "select REPLACE(UUID(),\"-\",\"\"),tor.id,null, 0, 1, null, now() from "
				+ srcTableName
				+ " tor "
				+ "where not EXISTS (SELECT 'x' from "
				+ destTableName
				+ " osd where osd.orderId = tor.id) "
				+ " and tor.STATUS IN ('4', '5') and tor.createTime > DATE_ADD(now(),INTERVAL "
				+ priTime + " minute)";

		System.out.println("sql : " + sql);

		try {
			ps = conn.prepareStatement(sql);
			int num = ps.executeUpdate();
			System.out.println("deal num is : " + num);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("data deal success!");
			closeAll(null, ps, null);
		}
	}

	public Connection getConn(String url, String userName, String passwd) {
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			conn = DriverManager.getConnection(url, userName, passwd);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

	public void closeAll(ResultSet rs, PreparedStatement stat, Connection conn) {
		if (rs != null)
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		if (stat != null)
			try {
				stat.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		if (conn != null)
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}

}
